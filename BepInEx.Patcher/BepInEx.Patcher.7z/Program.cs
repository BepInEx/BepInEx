﻿using BepInEx.Patcher.Internal;
using Mono.Cecil;
using Mono.Cecil.Cil;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BepInEx.Patcher
{
    class Program
    {
        const string originalDLL = @"M:\koikatu\KoikatuTrial_Data\Managed\Assembly-CSharp-original.dll";
        const string outputDLL = @"M:\koikatu\KoikatuTrial_Data\Managed\Assembly-CSharp.dll";
        const string referenceDir = @"M:\koikatu\KoikatuTrial_Data\Managed\";

        static void Main(string[] args)
        {
            var defaultResolver = new DefaultAssemblyResolver();
            defaultResolver.AddSearchDirectory(referenceDir);

            AssemblyDefinition assembly = AssemblyDefinition.ReadAssembly(originalDLL, new ReaderParameters {
                AssemblyResolver = defaultResolver
            });

            IPatchPlugin exitScene = new ExitScenePlugin();
            exitScene.Patch(assembly);

            IPatchPlugin slider = new SliderPlugin();
            exitScene.Patch(assembly);

            assembly.Write(outputDLL);
        }
    }
}
